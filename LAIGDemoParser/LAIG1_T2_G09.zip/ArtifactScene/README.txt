LAIG ArtifactScene T1

Provided by:
- Diogo Afonso Duarte Reis - up201505472@fe.up.pt
- Tiago Jos� Sousa Magalh�es - up201607931@fe.up.pt